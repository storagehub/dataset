
racoon - v8 2020-11-08 8:05pm
==============================

This dataset was exported via roboflow.ai on November 8, 2020 at 9:38 AM GMT

It includes 466 images.
Racoon are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise


